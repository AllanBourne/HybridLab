

Configuration Main
{

	Param ( [PSCredential]$AdminCredential, 
			[string]$DomainName, 
			[string]$domainNameNetbios, 
			[string]$ExchangeOrgName, 
			[string]$ExchangeProductKey,
			[string]$SourcePathSignInAssistant,
			[string]$TargetPathSignInAssistant,
			[string]$SourcePathAADPS,
			[string]$TargetPathAADPS,
			[Int]$RetryCount=20, 
			[Int]$RetryIntervalSec=30 )

	Import-DscResource -ModuleName PSDesiredStateConfiguration, xDisk, xNetworking, xPendingReboot, cDisk, xExchange, xSystemSecurity

    [PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${domainNameNetbios}\$($AdminCredential.UserName)", $AdminCredential.Password)


	Node localhost
	{

		[string]$DownloadsFolder = "f:\Downloads"

		LocalConfigurationManager            
		{            
			ActionAfterReboot = 'ContinueConfiguration'            
			ConfigurationMode = 'ApplyOnly'            
			RebootNodeIfNeeded = $true            
		} 

		xWaitforDisk Disk2
		{
			DiskNumber = 2
			RetryIntervalSec =$RetryIntervalSec
			RetryCount = $RetryCount
		}

		cDiskNoRestart ADDataDisk
		{
			DiskNumber = 2
			DriveLetter = "F"
		}

        xIEEsc DisableIEEsc
        {
            IsEnabled = $false
            UserRole = "Administrators"
        }

        xFirewall FWFileShare1
        {
            Name      = "File and Printer Sharing (NB-Datagram-In)"
            Ensure    = "Present"
            Enabled   = "True"
        }

        xFirewall FWFileShare2
        {
            Name      = "File and Printer Sharing (NB-Name-In)"
            Ensure    = "Present"
            Enabled   = "True"
        }

        xFirewall FWFileShare3
        {
            Name      = "File and Printer Sharing (NB-Session-In)"
            Ensure    = "Present"
            Enabled   = "True"
        }

        xFirewall FWFileShare4
        {
            Name      = "File and Printer Sharing (SMB-In)"
            Ensure    = "Present"
            Enabled   = "True"
        }



		# =================================
		# Desktop Experience requires multple reboots and careful handling

		Script InstallDesktopExperience
		{
			TestScript = {
				if ((Get-WindowsFeature desktop-experience).InstallState -like "Install*") {$true} Else {$false}
			}
			SetScript = {
				Add-WindowsFeature -Name Desktop-Experience
                Set-Service -name TrustedInstaller -startupType Disabled
                "Added Desktop Experience" | Set-Content f:\desktopexperience.txt
			}
			GetScript = {@{Result = "InstallDesktopExperience"}}
		}

		xPendingReboot FirstRebooDesktopExperience
		{
			Name      = "AfterDesktopExperience"
			DependsOn  = '[Script]InstallDesktopExperience'
		}

		Service EnableTrustedInstaller
		{
			Name =        "TrustedInstaller"
			StartupType = "Manual"
            DependsOn  = '[xPendingReboot]FirstRebooDesktopExperience'
		}
        
        Script SetRebootFlag
        {
			TestScript = {
				if (Test-Path f:\desktopexperience.txt) {$false} else {$true}
			}
			SetScript = {
				Start-Sleep -Seconds 60
				Remove-Item f:\desktopexperience.txt -Force
                $global:DSCMachineStatus = 1
			}
			GetScript = {@{Result = "SetRebootFlag"}}
            DependsOn  = '[Service]EnableTrustedInstaller'            
        }

        xPendingReboot SecondRebooDesktopExperience
		{
			Name      = "AfterDesktopExperience2"
			DependsOn  = '[Script]SetRebootFlag'
		}

		# Done with Desktop experience
		# =================================



		WindowsFeature ASHTTPActivation
		{
			Ensure = "Present" 
			Name = "AS-HTTP-Activation"
		}

		WindowsFeature NETFramework45Features
		{
			Ensure = "Present" 
			Name = "NET-Framework-45-Features"
		}

		WindowsFeature RPCoverHTTPproxy
		{
			Ensure = "Present" 
			Name = "RPC-over-HTTP-proxy"
		}

		WindowsFeature RSATClustering
		{
			Ensure = "Present" 
			Name = "RSAT-Clustering"
		}

		WindowsFeature RSATADDS
		{
			Ensure = "Present" 
			Name = "RSAT-ADDS"
		}

		WindowsFeature RSATClusteringCmdInterface
		{
			Ensure = "Present" 
			Name = "RSAT-Clustering-CmdInterface"
		}

		WindowsFeature RSATClusteringMgmt
		{
			Ensure = "Present" 
			Name = "RSAT-Clustering-Mgmt"
		}

		WindowsFeature RSATClusteringPowerShell
		{
			Ensure = "Present" 
			Name = "RSAT-Clustering-PowerShell"
		}

		WindowsFeature WebMgmtConsole
		{
			Ensure = "Present" 
			Name = "Web-Mgmt-Console"
		}

		WindowsFeature WASProcessModel
		{
			Ensure = "Present" 
			Name = "WAS-Process-Model"
		}

		WindowsFeature WebAspNet45
		{
			Ensure = "Present" 
			Name = "Web-Asp-Net45"
		}

		WindowsFeature WebBasicAuth
		{
			Ensure = "Present" 
			Name = "Web-Basic-Auth"
		}

		WindowsFeature WebClientAuth
		{
			Ensure = "Present" 
			Name = "Web-Client-Auth"
		}

		WindowsFeature WebDigestAuth
		{
			Ensure = "Present" 
			Name = "Web-Digest-Auth"
		}

		WindowsFeature WebDirBrowsing
		{
			Ensure = "Present" 
			Name = "Web-Dir-Browsing"
		}

		WindowsFeature WebDynCompression
		{
			Ensure = "Present" 
			Name = "Web-Dyn-Compression"
		}
	  
		WindowsFeature WebHttpErrors
		{
			Ensure = "Present" 
			Name = "Web-Http-Errors"
		}

		WindowsFeature WebHttpLogging
		{
			Ensure = "Present" 
			Name = "Web-Http-Logging"
		}

		WindowsFeature WebHttpRedirect
		{
			Ensure = "Present" 
			Name = "Web-Http-Redirect"
		}

		WindowsFeature WebHttpTracing
		{
			Ensure = "Present" 
			Name = "Web-Http-Tracing"
		}

		WindowsFeature WebISAPIExt
		{
			Ensure = "Present" 
			Name = "Web-ISAPI-Ext"
		}

		WindowsFeature WebISAPIFilter
		{
			Ensure = "Present" 
			Name = "Web-ISAPI-Filter"
		}

		WindowsFeature WebLgcyMgmtConsole
		{
			Ensure = "Present" 
			Name = "Web-Lgcy-Mgmt-Console"
		}

		WindowsFeature WebMetabase
		{
			Ensure = "Present" 
			Name = "Web-Metabase"
		}

		WindowsFeature WebMgmtService
		{
			Ensure = "Present" 
			Name = "Web-Mgmt-Service"
		}

		WindowsFeature WebNetExt45
		{
			Ensure = "Present" 
			Name = "Web-Net-Ext45"
		}

		WindowsFeature WebRequestMonitor
		{
			Ensure = "Present" 
			Name = "Web-Request-Monitor"
		}

		WindowsFeature WebServer
		{
			Ensure = "Present" 
			Name = "Web-Server"
		}

		WindowsFeature WebStatCompression
		{
			Ensure = "Present" 
			Name = "Web-Stat-Compression"
		}

		WindowsFeature WebStaticContent
		{
			Ensure = "Present" 
			Name = "Web-Static-Content"
		}
		
		WindowsFeature WebWindowsAuth
		{
			Ensure = "Present" 
			Name = "Web-Windows-Auth"
		} 

		WindowsFeature WebWMI
		{
			Ensure = "Present" 
			Name = "Web-WMI"
		}

		WindowsFeature WindowsIdentityFoundation
		{
			Ensure = "Present" 
			Name = "Windows-Identity-Foundation"
		}
	
		File CreateDownloadFolder
		{
			DestinationPath = "f:\Downloads"
			Ensure = "Present"
			Type = "Directory"
		}

		Script DownloadExchange2013CU12
		{
			TestScript = {
				Test-Path "F:\downloads\Exchange2013-x64-cu12.exe"
			}
			SetScript ={
				$source = "https://download.microsoft.com/download/2/C/1/2C151059-9B2A-466B-8220-5AE8B829489B/Exchange2013-x64-cu12.exe"
				$dest = "F:\downloads\Exchange2013-x64-cu12.exe"
                $webclient = new-object System.Net.WebClient
                $webclient.DownloadFile($source, $dest)
			}
			GetScript = {@{Result = "DownloadExchange2013CU12"}}
			DependsOn = "[File]CreateDownloadFolder"
		}

		Script UnpackExchange
		{
			TestScript = {
				Test-Path "f:downloads\Exchange2013Source\setup.exe"
			}
			SetScript ={
				$FilePath = "F:\downloads\Exchange2013-x64-cu12.exe"
				$ExtractLocation = "f:\downloads\Exchange2013Source\"
				$appArgs = '/quiet /extract:"' + $ExtractLocation + '"'
				Start-Process $FilePath $appArgs -PassThru | Wait-Process
			}
			GetScript = {@{Result = "UnpackExchange"}}
			DependsOn = "[Script]DownloadExchange2013CU12"
		}

		<#
		Package OCRuntime {
            Name = "Runtime Exchange"
            Path = "F:\downloads\UcmaRuntimeSetup.exe"
            Productid = "ED98ABF5-B6BF-47ED-92AB-1CDCAB964447"
            Arguments = "/passive /norestart"
            Ensure = "Present"
            returncode = 0
        }
		#>

		Script DownloadUnifiedCommunicationsManagedAPI4Runtime
		{
			TestScript = {
				Test-Path "F:\downloads\UcmaRuntimeSetup.exe"
			}
			SetScript ={
				$source = "https://download.microsoft.com/download/2/C/4/2C47A5C1-A1F3-4843-B9FE-84C0032C61EC/UcmaRuntimeSetup.exe"
				$dest = "F:\downloads\UcmaRuntimeSetup.exe"
				Invoke-WebRequest $source -OutFile $dest
			}
			GetScript = {@{Result = "DownloadUnifiedCommunicationsManagedAPI4Runtime"}}
			DependsOn = "[File]CreateDownloadFolder","[Script]UnpackExchange"
		}
		

		Script InstallUnifiedCommunicationsManagedAPI4Runtime
		{

			TestScript = {
				if (Get-ItemProperty "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\UCMA4" -erroraction SilentlyContinue) {$true} Else {$false}
			}
			SetScript ={
				$FilePath = "F:\downloads\UcmaRuntimeSetup.exe"
				$appArgs = "/quiet /norestart"
				Start-Process $FilePath $appArgs -PassThru | Wait-Process
			}
			GetScript = {@{Result = "InstallUnifiedCommunicationsManagedAPI4Runtime"}}
			DependsOn = "[Script]DownloadUnifiedCommunicationsManagedAPI4Runtime"

		}

		Script DownloadSignInAssistant
		{
			TestScript = {
				Test-Path ($using:DownloadsFolder + "\" + $using:TargetPathSignInAssistant)
			}
			SetScript ={
                Invoke-WebRequest $Using:SourcePathSignInAssistant -OutFile ($using:DownloadsFolder + "\" + $using:TargetPathSignInAssistant)
			}
			GetScript = {@{Result = "DownloadSignInAssistant"}}
			DependsOn = "[File]CreateDownloadFolder"
		}

		Package InstallSignInAssistant {
            Name = "Microsoft Online Services Sign-in Assistant"
            Path = ($DownloadsFolder + "\" + $TargetPathSignInAssistant)
            Productid = "D8AB93B0-6FBF-44A0-971F-C0669B5AE6DD"
            Arguments = "/passive /norestart"
            Ensure = "Present"
            returncode = 0
			DependsOn = "[script]DownloadSignInAssistant"
        }

		Script DownloadAADPowerShell
		{
			TestScript = {
				Test-Path ($using:DownloadsFolder + "\" + $using:TargetPathAADPS)
			}
			SetScript ={
                Invoke-WebRequest $Using:SourcePathAADPS -OutFile ($using:DownloadsFolder + "\" + $using:TargetPathAADPS)
			}
			GetScript = {@{Result = "DownloadAADPowerShell"}}
			DependsOn = "[File]CreateDownloadFolder"
		}

		Package InstallAADPowerShell {
            Name = "Windows Azure Active Directory Module for Windows PowerShell"
            Path = ($DownloadsFolder + "\" + $TargetPathAADPS)
            Productid = "43CC9C53-A217-4850-B5B2-8C347920E500"
            Arguments = "/passive /norestart"
            Ensure = "Present"
            returncode = 0
			DependsOn = "[script]DownloadAADPowerShell"
        }

		xPendingReboot BeforeExchangeInstall
		{
			Name      = "BeforeExchangeInstall"
			DependsOn  = '[Script]InstallUnifiedCommunicationsManagedAPI4Runtime','[script]UnpackExchange'
		}

		xExchInstall InstallExchange
		{
			Path       = "f:\downloads\Exchange2013Source\setup.exe"
			Arguments  = "/mode:Install /role:Mailbox,ClientAccess /Iacceptexchangeserverlicenseterms /OrganizationName:$ExchangeOrgName"
			Credential = $DomainCreds
			DependsOn  = '[xPendingReboot]BeforeExchangeInstall'
		}
		
		xPendingReboot AfterExchangeInstall
		{
			Name      = "AfterExchangeInstall"
			DependsOn = '[xExchInstall]InstallExchange'
		}

		xExchExchangeServer EXServer 
		{ 
			Identity            = ($env:COMPUTERNAME)
			Credential          = $DomainCreds
			ProductKey          = $ExchangeProductKey
			AllowServiceRestart = $true
			DependsOn           = '[xPendingReboot]AfterExchangeInstall'
		} 


	}

}